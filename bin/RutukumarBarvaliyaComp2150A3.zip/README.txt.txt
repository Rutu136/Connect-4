Student ID:- 7870807
Student Name:- Rutukumar Barvaliya

-->> I just did the GUI off, 
-->> When you will run the code, you will see the Text based output. it will ask      you for the column where you want to play.
-->> For turning on the GUI just comment out the stuff that right above the TU 	      object in HumanPlayer class.
-->> When the Computer wins my GUI window will be closed and there will be            output in the consol like "Computer Wins".
