//-----------------------------------------
// NAME			  : Rutukumar Barvaliya 
// STUDENT NUMBER : 7870807
// COURSE		  : COMP 2150
// INSTRUCTOR	  : Mike Domaratzki
// ASSIGNMENT	  : assignment 2
// QUESTION		  : Main File    
// 
// REMARKS        : This will run the game by making an object of the gameLogic 
//					implementation class's.
//
//-----------------------------------------

public class main 
{
	public static void main(String[] args)
	{
		ConnectFour CF = new ConnectFour();
		CF.runGame();
	}
}
