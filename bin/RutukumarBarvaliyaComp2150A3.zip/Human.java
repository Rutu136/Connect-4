public interface Human {
     void setAnswer(int col);
}
